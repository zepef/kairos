# Handoff : Kairos — Assistant de tâches vocal, offline-first (v0.8)

> **Baseline pour redesign en Ultra Code.** Ce document décrit l'état **actuel** de l'interface Kairos avec une précision maximale (mesures, couleurs, typographie, états, machine à états). Il sert de point de départ documenté sur lequel appliquer les ordres de redesign. Toute instruction de redesign doit être comprise comme une transformation de cette baseline.

---

## 1. Overview

**Kairos** est un assistant de tâches **100 % on-device / offline** et **bilingue FR-EN**. Le produit est **voice-first** : l'écran est un filet de sécurité, l'**orbe vocale** est le cœur de l'expérience. Boucle centrale : `maintenir → parler → compris → répondu à voix haute`. Le modèle (Gemma 4 · E2B, ~3 Go) est téléchargé une seule fois puis tout tourne localement (`0 donnée envoyée`).

Deux artefacts HTML :

| Fichier | Rôle |
|---|---|
| `Kairos Prototype.dc.html` | **Prototype fonctionnel** — l'app réelle, pilotée par thème, 5 écrans, machine à états vocale scriptée. **C'est la référence d'implémentation.** |
| `Kairos Redesign.dc.html` | **Canvas d'exploration** — 3 directions visuelles (Signal / Local / On-Device) × 3 écrans statiques chacune, + le tour « sélecteur de thème ». Sert de moodboard/rationale. |

Le prototype fusionne les 3 directions en **3 thèmes commutables à chaud** : `signal`, `local`, `onDevice`. Tous les écrans partagent le **même markup** piloté par variables CSS (`--accent`, `--bg`…) ; changer de thème re-skinne l'app instantanément.

---

## 2. À propos des fichiers de design

Les fichiers de ce bundle sont des **références de design créées en HTML** (Design Components — prototypes montrant l'apparence et le comportement voulus), **pas du code de production à copier tel quel**. La tâche est de **recréer ces designs dans l'environnement du codebase cible** (React, Vue, SwiftUI, natif…) en suivant ses patterns et librairies établis. Si aucun environnement n'existe encore, choisir le framework le plus adapté (une app mobile portrait ⇒ React Native / SwiftUI / Flutter sont naturels) et y implémenter les designs.

Notes techniques sur le format source (à ne PAS reproduire) :
- Le format `.dc.html` est un runtime maison (`support.js`, balises `<x-dc>`, `<sc-if>`, `<sc-for>`, holes `{{ }}`). **Ignorer ce runtime** ; ne réutiliser que la structure, les styles inline, les tokens et la logique de la classe `Component`.
- Les styles sont **inline** ; les seules règles globales sont les `@keyframes` et un reset dans `<helmet>`.

---

## 3. Fidélité

**High-fidelity (hifi).** Couleurs, typographie, espacements et interactions sont définitifs. Recréer l'UI au pixel près avec les librairies/patterns du codebase cible. Les valeurs exactes sont en §7 (Design Tokens).

---

## 4. Cadres (frames) & chrome commun

### Téléphone portrait
- **Bezel** : largeur `322px`, padding `12px`, `border-radius:46px`, `background:var(--bezel)`, `box-shadow:0 40px 80px -30px rgba(20,25,40,.55)`.
- **Écran** : hauteur `668px`, `border-radius:36px`, `overflow:hidden`, `background:var(--bg)`, `color:var(--ink)`, `display:flex; flex-direction:column`.
- **Home indicator** : barre `110×5px`, `border-radius:3px`, `background:var(--indicator)`, centrée, `bottom:8px`.

### Barre de statut (tous les écrans portrait)
- Padding `12px 22px 2px`, `font:600 12px var(--font)`, `color:var(--ink)`.
- Gauche : `9:41`. Droite : glyphe avion `✈` en `var(--accent)` (indique offline) + jauge batterie (rectangle `20×11px`, bordure `1.5px var(--ink)`, remplissage `72%`, petit ergot `2×5px`).

### Calendrier paysage
- **Bezel** : largeur `720px`, padding `12px`, `border-radius:42px`.
- **Écran** : hauteur `346px`, `border-radius:30px`.

---

## 5. Écrans / Vues

Écrans du prototype : `picker`, `home`, `list`, `settings`, `calendar` (états `screen`). Tous existent pour les 3 thèmes.

### 5.1 Picker (sélection du thème pendant le téléchargement du modèle)
- **But** : pendant le download (~3 Go, temps mort aujourd'hui), l'utilisateur choisit un style. L'app se re-skinne en direct à chaque tap.
- **Header** : logo `26×26`, `border-radius:7px`, `background:var(--logoBg)`, `box-shadow:var(--logoShadow)` + « Kairos » `600 17px var(--display)`. À droite : toggle langue EN/FR (pill, `background:var(--surface)`, bordure `1px var(--line)`, `border-radius:999px`, padding 3px ; segment actif = `background:var(--accent)`, texte `var(--bg)` ; inactif = texte `var(--muted)`).
- **Titre** : `600 21px var(--display)`, `letter-spacing:-0.01em` — « Choisissez votre style » / « Choose your style ». Sous-titre `12.5px var(--muted)` — « Modifiable à tout moment dans les Réglages. ».
- **3 cartes thème** (gap `11px`, padding `13px`, `border-radius:16px`, `background:var(--surface)`, bordure `1.5px var(--line)`, `cursor:pointer`). Carte sélectionnée : bordure surimposée `2px var(--accent)` (`inset:-2px`, `border-radius:18px`) + badge check `24×24` cercle `var(--accent)`, glyphe `✓` `var(--bg)`, position `top:-9px; right:-9px`.
  - **Avatar `46×46` cercle**, `flex:none` :
    - *Signal* : `conic-gradient(from 200deg,#2f6fed,#17b3b0,#2f6fed)`, disque interne `37×37` `var(--surface)`, chevron (deux bords `3px`, rotation -45°).
    - *Local* : `radial-gradient(130% 130% at 32% 26%, #fbf7ee, #dccdb2)`, pastille `22×22` `#b5623c` avec micro crème (`#fbf3e7`).
    - *On-Device* : `radial-gradient(130% 130% at 30% 24%,#1b2029,#0f1218)`, 3 barres equalizer (`#2ee6c6`, `#2ee6c6`, `#7c8cff`) animées `keq`.
  - **Texte** : nom `600 15px var(--display) var(--ink)` ; description `12px var(--muted)`.
    - FR : « Lumineux · évolue la marque » / « Chaleureux · vos données chez vous » / « Technique · pour les initiés ».
- **Barre de progression** (bas) : ligne label/pourcentage (`var(--muted)` / `700 12px var(--accent)`, `font-variant-numeric:tabular-nums`) ; piste `height:6px`, `border-radius:3px`, `background:var(--line)` ; remplissage `linear-gradient(90deg,var(--accent),var(--accent2))`, `transition:width .4s ease`, largeur = `loadPct%`.
  - Quand `loadPct>=100` : bouton « Commencer » / « Get started » — padding `13px`, `border-radius:14px`, `background:var(--accent)`, texte `var(--bg)`, `600 15px var(--display)`, `box-shadow:0 12px 24px -10px var(--accent)`.
  - Pendant le chargement : caption `11px var(--muted)` — « Une seule fois. Ensuite, 100 % hors-ligne. ».

### 5.2 Home (orbe vocale)
- **But** : écran d'accueil ; on maintient l'orbe pour dicter une commande.
- **Header** : logo + « Kairos ». Cluster droit (gap `9px`) : toggle langue, puis **3 boutons ronds `30×30`** (`background:var(--surface)`, bordure `1px var(--line)`, `border-radius:50%`, `color:var(--muted)`, `cursor:pointer`) :
  1. **☰ Liste** (`font-size:15px`, `title="Liste"`) → ouvre `list`.
  2. **▦ Calendrier** (`font-size:14px`, `title="Calendrier"`) → ouvre `calendar`.
  3. **⚙ Réglages** (`font-size:15px`, `title="Réglages"`) → ouvre `settings`.
- **Panneau vocal** (visible si `vState≠idle`) : marge `13px 16px 0`, padding `13px 14px`, `border-radius:16px`, `background:var(--panelBg)`, bordure `1px var(--panelBorder)`, `box-shadow:0 12px 26px -20px rgba(20,25,40,.5)`. Contenu selon l'état :
  - Citation entendue : `12px italic var(--muted)`, entre guillemets « … ».
  - *listening* : barres eq (`4px`, `var(--listen)`, `keq .8s`) + « À l'écoute… » `600 13.5px var(--listen)`.
  - *understanding* : 3 points (`6px`, `var(--muted)`, `kdots 1.2s`) + « Compréhension… ».
  - *result* : emoji `19px` + titre `600 14px var(--ink)` + hint `11px var(--muted)`.
  - *noteAsk* : emoji 📝 + titre + hint `11px var(--accent)` « Maintenez pour dicter la note ».
  - *disambig* : titre + liste de candidats cliquables (num `var(--accent)` + emoji + titre + due coloré).
- **Orbe** : zone tactile `210×210` (`onPointerDown`/`Up`/`Leave`, `touch-action:none`, `user-select:none`).
  - Anneaux idle : `inset:26px`, bordure `1.5px var(--accent)` puis `var(--accent2)`, `opacity:.3`, `kpulse 3.4s` (2e décalé `1.7s`).
  - Anneaux listening : `inset:12px`, bordure `2px var(--listen)`, `kpulse 2.2s` (décalé `1.1s`).
  - Disque `150×150`, `background:var(--orbDisc)`, `box-shadow:var(--orbShadow)`, `kbreathe 4s`.
  - Cœur idle par thème : *signal* chevron dans disque conique `98px` ; *local* micro clay `70px` ; *on-device* barres eq `36px` + label `10px 'IBM Plex Mono' var(--accent)` « gemma-4-e2b ».
  - Cœur listening : 5 barres eq `6px`, `var(--listen)`, hauteur `52px`, `keq 1s` décalées.
- **Label orbe** : `600 17px var(--display)` (idle « Maintenez pour parler » / listening « Relâchez pour envoyer » / understanding « Compréhension… »). Sub `12.5px var(--muted)`.
- **Liste « À venir »** (bas) : titre `700 11px var(--font)`, `letter-spacing:.14em`, uppercase, `var(--muted)`. Lignes : padding `9px 0`, `border-bottom:1px solid var(--line)` ; num (`700 12px var(--muted)`, largeur 14px) + emoji `16px` + titre `14.5px var(--ink)` + éventuel 📝 + due `600 12.5px` couleur selon `dueKind`.

### 5.3 List (toutes les tâches, groupées par dossier)
- **But** : consulter/gérer les tâches par catégorie.
- **Header** : titre `600 20px var(--display)` (« Toutes les tâches » / « All tasks ») + « ✕ Fermer » `13px var(--muted)` → `home`.
- Panneau résultat optionnel (même style, compact).
- **Scroll** (`overflow:auto`, scrollbar masquée). Pour chaque dossier :
  - En-tête : label uppercase `700 11px var(--display)`, `letter-spacing:.08em`, `var(--accent)` + trait `1px var(--line)` + compteur `11px var(--muted)`.
  - Carte : `background:var(--surface)`, bordure `1px var(--line)`, `border-radius:12px`. Item : padding `11px 13px`, `border-bottom:1px solid var(--line)` ; num + emoji `15px` + titre `14.5px var(--ink)` (+ pastille urgente `7px var(--danger)`) + note italique `12px var(--muted)` préfixée 📝 + due `600 12.5px`.
- **Orbe compacte** centrée en bas : `56×56`, `background:var(--orbDisc)`, `box-shadow:var(--orbShadow)` (push-to-talk).

### 5.4 Settings (Réglages)
- **Header** : « Réglages » `600 20px var(--display)` + « ✕ Fermer ».
- **Apparence** : titre section `700 11px`, `letter-spacing:.12em`, uppercase, `var(--muted)`. 3 tuiles (`flex:1`, padding `14px 6px`, `border-radius:14px`, `background:var(--surface)`, bordure `2px` = `var(--accent)` si sélectionnée sinon `var(--line)`) : avatar `40×40` (mêmes styles que le picker, réduits) + nom `600 12px var(--font)`.
- **Langue** : carte surface/line `border-radius:14px`, padding `14px` — « Interface et voix » `14.5px var(--ink)` + toggle EN/FR.
- **Voix** : carte — « Réponses vocales » + sous-texte `12px var(--muted)` « Kairos répond à voix haute » + **switch** `46×27`, `border-radius:999px`, piste `var(--accent)` (on) / `var(--line)` (off), knob `21×21` blanc `box-shadow:0 1px 3px rgba(0,0,0,.3)`, `transform:translateX(19px)` on / `0` off, `transition:.2s`.
- **Modèle et confidentialité** : carte — « Gemma 4 · E2B » + méta `12px` « 3 Go · sur l'appareil » + « Prêt » `600 12px var(--accent2)` ; ligne « ✈ 100 % hors-ligne · 0 donnée envoyée ».
- **Footer** : « Kairos · version 0.8 » `500 12px var(--muted)`, centré.

### 5.5 Calendar (paysage — Jour / Semaine / Mois / Année)
- **Header** : titre `600 18px var(--display)` + sub `12px var(--muted)` (« · hors-ligne » / « · offline ») ; segmented control (pills, actif `var(--accent)`/`var(--bg)`) Jour/Semaine/Mois/Année ; « ✕ Fermer ».
- **Semaine** : grille 7 colonnes, gap `8px` ; carte jour `min-height:210px`, surface/line `border-radius:12px`, padding `9px 8px`. En-tête jour : nom uppercase `11px var(--muted)` + date `700 14px var(--display)` (aujourd'hui = `var(--accent)`). Chips : `background:var(--chipBg)`, `border-left:3px solid <color>`, `border-radius:6px`, padding `5px 7px` ; emoji + heure gras + titre.
- **Mois** : grille 7 colonnes, gap `5px` ; en-têtes jours `600 10px var(--muted)` ; cellules `min-height:38px`, `border-radius:8px`, bordure `1px var(--line)`, date `600 11px` + points colorés `6px`.
- **Jour** : lignes horaires `08:00`→`19:00`, `min-height:34px`, `border-top:1px solid var(--line)` ; label heure `600 11px var(--muted)` (44px) ; bloc événement `border-left:3px solid <color>`, `border-radius:7px`, emoji + titre `600 13px` + catégorie `11px var(--muted)`.
- **Année** : grille 6 colonnes, gap `10px` ; 12 mini-mois (surface, bordure `var(--accent)` si mois courant), label `600 11px var(--display)`, mini-grille 7 col de pastilles (`aspect-ratio:1`, `var(--line)` ou `var(--accent)` si jour actif).
- **Orbe flottante** bas-droite : `50×50`.

---

## 6. Interactions & comportement

### Boucle vocale (machine à états `vState`)
`idle → listening → understanding → (result | noteAsk | disambig) → idle`
- **`onPointerDown`** sur l'orbe (home / list / calendar) → `vState:"listening"`, affiche `heard = SCRIPT[lang][step]`.
- **`onPointerUp` / `onPointerLeave`** → `vState:"understanding"`, puis après **1300 ms** appelle `execute()`.
- **`execute()`** avance un script démo de 8 étapes (`step` 0→7, boucle) :
  | step | action | résultat |
  |---|---|---|
  | 0 | « ajoute appeler Paul demain 10h au bureau, c'est urgent » | crée tâche Paul (Travail, urgent) → `result` |
  | 1 | « ajoute acheter du pain ce soir à la maison » | crée tâche pain (Maison) → `result` |
  | 2 | « affiche toutes mes tâches » | ouvre `list` → `result` |
  | 3 | « ajoute une note à dentiste » | passe en `noteAsk` (demande la note) |
  | 4 | « apporter aussi la carte vitale » | enregistre la note sur Dentiste → `result` |
  | 5 | « supprime une tâche » | passe en `disambig` (liste de candidats) |
  | — | tap sur un candidat | supprime, `result`, `step→6` |
  | 6 | « marque appeler Paul comme faite » | marque done → `result` |
  | 7 | « annule » | restaure l'état précédent (`_undo`) → reset `step→0` |
- Chaque `result` réversible porte le hint « Dites « annule » pour revenir en arrière » / « Say "undo" to reverse ».

### Navigation
- Header home : ☰ → `list`, ▦ → `calendar` (range `week`), ⚙ → `settings`.
- « ✕ Fermer » (list/settings/calendar) → `home`.
- Picker « Commencer » → `home` avec une alerte initiale « 1 tâche en retard : Facture électricité. » (emoji ⏰).

### Thème (re-skin live)
- `pick(theme)` → `setState({theme})`. Aucune transition de page ; toutes les variables CSS changent, l'app se re-peint. Accessible depuis le picker ET les tuiles Apparence des réglages.

### Langue
- `toggleLang()` bascule fr↔en, **réinitialise la démo** (`step:0`, `vState:"idle"`), reseed les tâches dans la langue choisie.

### Autres
- `toggleTts()` : bascule les réponses vocales (switch).
- Calendrier : `setRange('day'|'week'|'month'|'year')`.

### Animations (`@keyframes`)
| Nom | Effet | Usage |
|---|---|---|
| `kbreathe` | scale 1 → 1.04 → 1 | disque de l'orbe (4s), avatars picker |
| `kpulse` | scale .86→1.5, opacity .5→0 | anneaux de l'orbe (3.4s idle / 2.2s listening) |
| `keq` | scaleY .3 → 1 | barres equalizer (0.8–1.1s, décalages .15–.2s) |
| `kdots` | opacity .25 → 1 | points « Compréhension… » (1.2s) |
| `kglow` | opacity .45 → .95 | point offline vert (2s) — direction On-Device |
| `kspin` | rotate 360° | anneau pointillé (16s) — direction On-Device |

Toutes en `ease-in-out` sauf `kpulse` (`ease-out`), `kspin` (`linear`).

---

## 7. Design Tokens (par thème)

Chaque thème est un jeu complet de variables CSS. **`--font`** = corps de texte, **`--display`** = titres.

### 7.1 Signal — « lumineux, confiant » (défaut)
```
--bg:        #f6f8fc      --surface:   #ffffff
--ink:       #14213a      --muted:     #8793a3      --line: #e6ecf4
--accent:    #2f6fed      --accent2:   #17b3b0
--listen:    #2e9e5b      --danger:    #e0564b
--bezel:     #0b0b0d      --indicator: rgba(20,25,40,.22)
--panelBg:   #ffffff      --panelBorder: #e2e9f3     --chipBg: #eaf1ff
--display:   'Space Grotesk'    --font: 'Hanken Grotesk'
--logoBg:    conic-gradient(from 200deg,#2f6fed,#17b3b0,#2f6fed)
--orbDisc:   radial-gradient(140% 140% at 30% 24%,#ffffff 0%,#ecf3ff 46%,#ddedff 100%)
--orbShadow: 0 20px 44px -12px rgba(47,111,237,.5), inset 0 0 0 1.5px rgba(47,111,237,.12)
```

### 7.2 Local — « chaleureux, humain, analogique »
```
--bg:        #f7f2e8      --surface:   #fbf7ee
--ink:       #2b2620      --muted:     #9a8f7c      --line: #e5dccb
--accent:    #b5623c      --accent2:   #7c8c5a
--listen:    #7c8c5a      --danger:    #c0563a
--bezel:     #171310      --indicator: rgba(60,45,25,.22)
--panelBg:   #fbf7ee      --panelBorder: #e3d8c4     --chipBg: #f3ead9
--display:   'Newsreader' (serif)    --font: 'Hanken Grotesk'
--logoBg:    #b5623c
--orbDisc:   radial-gradient(130% 130% at 32% 26%,#fbf7ee 0%,#ece1cd 55%,#dccdb2 100%)
--orbShadow: 0 16px 36px -12px rgba(78,64,42,.5), inset 0 -7px 15px rgba(120,96,60,.18), inset 0 2px 6px rgba(255,255,255,.75)
```

### 7.3 On-Device — « technique, offline-first »
```
--bg:        #0b0d11      --surface:   #12151c
--ink:       #e7ecf2      --muted:     #8791a0      --line: #1f242e
--accent:    #2ee6c6      --accent2:   #7c8cff
--listen:    #2ee6c6      --danger:    #ff7a6b
--bezel:     #000000      --indicator: rgba(255,255,255,.28)
--panelBg:   #12151c      --panelBorder: #1f242e     --chipBg: #161b24
--display:   'IBM Plex Sans'    --font: 'IBM Plex Sans'   (accents en 'IBM Plex Mono')
--logoBg:    radial-gradient(130% 130% at 30% 24%,#1b2029,#0f1218)
--orbShadow: 0 0 48px -6px rgba(46,230,198,.4), inset 0 0 0 1px rgba(46,230,198,.28)
```

### 7.4 Échelles communes
- **Rayons** : puces/toggles `999px` ; cartes `12–16px` ; tuiles réglages `14px` ; écran phone `36px` ; bezel `46px` (portrait) / `42px` (paysage) ; calendrier écran `30px`.
- **Typo (px)** : 10–11 (méta/mono, uppercase `letter-spacing .08–.14em`) · 12–12.5 (labels, dues) · 13.5–14.5 (corps) · 15 (noms) · 17 (label orbe, titre app) · 18–21 (titres écran) · 26–40 (titres du canvas d'exploration).
- **Poids** : 400 (corps), 500 (méta), 600 (titres/labels), 700 (uppercase, nums).
- **Fond desktop du prototype** : `#e8eaee` (mockup posé sur gris neutre).
- **Statuts d'échéance (`dueKind` → couleur)** : `accent → var(--accent)`, `soon → var(--accent2)`, `danger → var(--danger)`.

---

## 8. State management

Toutes les données vivent dans le state de la classe `Component` (aucun fetch — 100 % offline).

**State :**
```
theme:  'signal' | 'local' | 'onDevice'   // thème actif
screen: 'picker' | 'home' | 'list' | 'settings' | 'calendar'
lang:   'fr' | 'en'
loadPct: number                            // 8 → 100, +7..20 toutes les 430ms
tasks:  Task[]                             // voir modèle ci-dessous
vState: 'idle' | 'listening' | 'understanding' | 'result' | 'noteAsk' | 'disambig'
heard, summary, summaryEmoji, summaryHint: string
step:   0..7                               // pointeur du script démo
calRange: 'day' | 'week' | 'month' | 'year'
ttsOn:  boolean
candidates: Task[] | null                  // pour la désambiguïsation
noteTarget: number | null                  // id de tâche recevant une note
```

**Modèle `Task` :**
```
{ id:number, emoji:string, title:string, cat:string,
  due:string, dueKind:'accent'|'soon'|'danger',
  note?:string, urgent?:boolean, done?:boolean }
```

**Seeds** (dépendent de `lang`) :
- `seed(lang)` : Dentiste/Dentist (Santé, Ven 14:00, note « anciennes radios / old X-rays ») + Facture électricité/Electricity bill (Finances, En retard/Overdue, danger).
- `paulTask` : Appeler Paul/Call Paul (Travail/Work, Demain 10:00, urgent).
- `breadTask` : Acheter du pain/Buy bread (Maison/Home, Ce soir/Tonight, soon).

**Dérivés (à recalculer au render) :**
- `upcoming` = 4 premières tâches non terminées.
- `folders` = tâches non terminées groupées par `cat`, avec numérotation continue.
- Progression `loadPct` : intervalle 430 ms, incrément `Math.random()*13+7`, s'arrête à 100.

---

## 9. Bilingue (FR / EN)

Toutes les chaînes sont dans deux tables `STR.fr` / `STR.en` (clés identiques). Points d'attention pour la recréation :
- Le toggle langue affecte **interface ET voix**.
- Les dates/dues sont localisées (« Demain 10:00 » / « Tmrw 10:00 »).
- Jours (`DAYS`), mois (`MONTHS`) et titres calendrier sont localisés.
- Basculer la langue **réinitialise la démo vocale** (comportement voulu du prototype ; en production, ne pas réinitialiser les vraies tâches).

---

## 10. Assets

Aucune image bitmap. Tout est vectoriel/CSS :
- **Logo & orbes** : dégradés CSS + formes (chevron via bordures, micro, barres equalizer). Aucune icône importée.
- **Glyphes UI** : caractères Unicode (`✈ ✓ ✕ ▦ ☰ ⚙ ▾`) et emojis (`📞 🛒 💰 🏥 👪 📝 ⏰ ✅ ↩️ 🗑️`). En production, remplacer par le jeu d'icônes du codebase (les emojis catégorie peuvent devenir des icônes système).
- **Polices (Google Fonts)** : Space Grotesk (400–700), Hanken Grotesk (400–700), Newsreader (opsz 6–72, 400–700), IBM Plex Sans (400–700), IBM Plex Mono (400–600).

---

## 11. Fichiers du bundle

- `Kairos Prototype.dc.html` — **prototype fonctionnel** (référence d'implémentation ; toute la logique est dans la classe `Component` en bas du fichier).
- `Kairos Redesign.dc.html` — **canvas d'exploration** des 3 directions (rationale visuel).
- `support.js` — runtime du format `.dc.html` (fourni pour que les fichiers s'ouvrent ; **à ne pas porter** en production).
- `screenshots/` — **15 captures de référence** (PNG), une par écran × thème :
  - `picker-{signal,local,ondevice}.png`
  - `home-{signal,local,ondevice}.png`
  - `list-{signal,local,ondevice}.png`
  - `calendar-{signal,local,ondevice}.png` (vue Semaine)
  - `settings-{signal,local,ondevice}.png`

---

## 12. Notes pour le redesign en Ultra Code

- Ce README décrit la **baseline v0.8**. Chaque ordre de redesign transforme cet état ; conserver les invariants produit sauf indication contraire : **voice-first**, **offline / 0 donnée envoyée**, **bilingue FR-EN**, **thèmes commutables**.
- L'orbe et sa machine à états sont le cœur — préserver la boucle `maintenir → parler → compris → répondu` et la réversibilité (`annule`).
- Le système de thèmes repose entièrement sur les variables CSS de §7 : introduire toute nouvelle couleur via ces tokens, pas en dur.
